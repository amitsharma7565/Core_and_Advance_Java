public class LastCharOccurence1 {
 public static void main(String[] args) {
    String myStr = "Amit Diwan";
    int strLastIndex = 0;
    System.out.println("String: "+myStr);
    strLastIndex = myStr.lastIndexOf('i');
    System.out.println("The last index of character a in the string: "+strLastIndex);
 }
}