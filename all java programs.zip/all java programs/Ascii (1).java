public class Ascii
{
public static void main(String args[])
{
    for(int i=65;i<=122;i++)
    {
        System.out.println("The ASCII value of "+(char)i+" = "+i);
    }
}
}