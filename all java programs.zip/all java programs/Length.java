public class Length
 { 
       public static void main(String[] args) 
    { 
         String s1 = "Welcome"; 
         System.out.println("s1.length() = "+ s1.length()); 
         System.out.println("s1.charAt(1) = "+ s1.charAt(1)); 
         System.out.println("s1.concat(\"Everybody\") = "+s1.concat(" Everyboday")); 
     } 
 } 